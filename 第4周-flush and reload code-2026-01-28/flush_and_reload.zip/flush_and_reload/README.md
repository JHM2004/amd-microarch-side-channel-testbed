# DES密钥恢复实验运行指南

## 系统概述

本系统实现了基于Flush+Reload缓存侧信道攻击的DES密钥恢复攻击，从48bit轮密钥K1恢复完整的64bit DES密钥。系统包含以下核心组件：

- `des.c`：DES加密算法实现，包含完整的16轮加密功能
- `spy.c`：间谍进程实现，包含Flush+Reload攻击逻辑和密钥恢复功能
- `libdes.so`：DES加密共享库
- `Makefile`：编译配置文件

## 环境要求

### 硬件环境
- **CPU型号**: 11th Gen Intel(R) Core(TM) i5-1135G7 @ 2.40GHz
- **CPU核心数**: 2核
- **内存**: 2GB
- **架构**: x86_64
- **缓存行大小**: 64字节

### 软件环境
- **操作系统**: Ubuntu 20.04.6 LTS (Focal Fossa)
- **内核版本**: Linux 5.15.0-139-generic
- **编译器**: GCC 9.4.0

### 编译选项
```makefile
CC = gcc
CFLAGS = -O0 -g -march=native -Wall -fPIC -Wno-unused-result -fno-stack-protector
LDFLAGS = -ldl -pthread
```

**关键编译选项说明：**
- `-O0`: 禁用优化，确保内存访问不被编译器优化掉
- `-march=native`: 针对当前CPU架构优化
- `-fPIC`: 生成位置无关代码（共享库必需）
- `-no-pie`: 生成非位置无关可执行文件

## 快速启动

### 1. 编译项目

```bash
make clean && make
```

   这将生成以下文件：
   - `libdes.so`：DES加密共享库
   - `spy`：间谍进程可执行文件

### 2. 运行攻击

```bash
sudo taskset -c 0 nice -n -20 ./spy ./libdes.so
```

### 参数说明

- `<des_library>`：DES加密共享库的路径（`./libdes.so`）
- 目标密钥在代码中硬编码为 `0x133457799BBCDFF1`（NIST标准测试向量）

### 3. 验证DES实现（可选）

```bash
gcc -O0 -o test_des des.c
./test_des
```

## 系统设置（可选优化）

为了提高攻击成功率，可以进行以下系统设置：

### 1. 关闭地址空间布局随机化 (ASLR)

```bash
# 临时关闭ASLR
sudo sysctl -w kernel.randomize_va_space=0

# 验证ASLR是否已关闭
cat /proc/sys/kernel/randomize_va_space

# 实验完成后恢复ASLR（推荐）
sudo sysctl -w kernel.randomize_va_space=2
```

### 2. 禁用透明大页 (THP)

```bash
# 临时禁用THP
sudo sh -c 'echo never > /sys/kernel/mm/transparent_hugepage/enabled'

# 验证THP状态
cat /sys/kernel/mm/transparent_hugepage/enabled
```

### 3. 设置CPU性能模式

```bash
# 设置CPU为性能模式
sudo cpupower frequency-set -g performance

# 或设置最大频率
echo performance | sudo tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
```
## 实验结果分析

运行实验后，系统会输出以下信息：

1. **密钥重建测试**：
   - 验证密钥重建逻辑的正确性
   - 显示原始密钥和正确的K1

2. **攻击初始化**：
   - 加载DES共享库
   - 显示S-boxes的内存地址
   - 校准缓存阈值（命中/未命中周期数）
   - 计算R0和E(R0)

3. **多轮攻击**（默认7轮）：
   - 每轮对每个S-box的64个条目进行独立Flush+Reload攻击
   - 显示每个S-box检测到的最佳条目
   - 推导K1片段并组装成候选K1

4. **投票选择**：
   - 从多轮攻击中选择最可靠的K1候选值
   - 基于置信度和有效片段数量

5. **暴力搜索**：
   - 从K1候选值恢复完整的64位密钥
   - 使用明文-密文对验证候选密钥

6. **最终结果**：
   - 显示恢复的64位密钥
   - 与实际密钥比较
   - 验证加密结果

## 技术原理

### Flush+Reload攻击原理

1. **Flush阶段**：使用`clflush`指令将目标内存行从所有缓存层级中驱逐
2. **Trigger阶段**：让受害者执行加密操作，访问其需要的S-box条目
3. **Reload阶段**：测量重新加载目标内存行的时间
   - 时间短（缓存命中）：受害者访问了该条目
   - 时间长（缓存未命中）：受害者未访问该条目

### S-box访问与K1推导

1. **DES第一轮**：
   - 明文经过IP置换后分为L0和R0
   - R0经过E扩展成为48位的E(R0)
   - E(R0)与K1异或后分为8个6位块，分别输入8个S-box

2. **S-box索引计算**：
   - 6位输入：`b1 b2 b3 b4 b5 b6`
   - Row = `b1b6`（首尾两位）
   - Col = `b2b3b4b5`（中间四位）
   - S-box条目索引 = `row * 16 + col`

3. **K1片段推导**：
   - 已知：检测到的S-box条目索引、E(R0)对应片段
   - 计算：`K1_fragment = S_box_input ^ E_R0_fragment`
   - 其中 `S_box_input = (row << 5) | (col << 1) | row`（重建6位输入）

4. **密钥重建**：
   - 从48位K1和8位未知位（PC-2未选中的位）重建56位C1D1
   - 循环右移1位得到C0D0
   - 逆PC-1置换得到64位密钥（含奇偶校验位）